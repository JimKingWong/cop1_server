<?php

return [
    'Department'                                            => '组织架构',
	'Organizational'                                        => '组织架构',
    'Employee'                                              => '部门成员',
    'Department list'                                       => '部门管理',
    'Principal set'                                         => '设置负责部门',

];
