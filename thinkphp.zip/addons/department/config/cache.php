<?php 
 return array (
  'table_name' => 'fa_department,fa_department_admin',
  'self_path' => 'application/admin/lang/zh-cn/department',
  'update_data' => '',
  'addons_menu' => 'department',
);