require(['backend', 'fast', 'layer', 'form', 'toastr'], function (Backend, Fast, Layer, Form, Toastr) {
    Config.vtheme.filterPpage = Config.vtheme.filterPpage || []
    if (parent.vtheme && Config.vtheme.filterPpage.indexOf(`${Config.controllername}.${Config.actionname}`) === -1) {
        top.$ = $
        parent.$ = $
        function initDispatchEvent(fun) {
            // 获取 body 元素
            const bodyElement = document.body;
            bodyElement.dispatchEvent(fun);
        }

        Backend.api.addtabs = function (url, title, icon) {
            const myCustomEvent = new CustomEvent('custom-addtabs', {
                detail: { url, title, icon }
            });

            initDispatchEvent(myCustomEvent)
        }

        Backend.api.refreshmenu = function () {
            const myCustomEvent = new CustomEvent('custom-refreshmenu', {
                detail: {}
            });

            initDispatchEvent(myCustomEvent)
        }

        if (Config.vtheme.modal !== 'fast') {
            Fast.api.open = function (url, title, options) {
                const myCustomEvent = new CustomEvent('custom-open', {
                    detail: { url, title, options, betterform: Config.betterform }
                });
                initDispatchEvent(myCustomEvent)
            }
            Fast.api.close = (data) => {
                const callback = top.window[parent.window.modalName].callback;
                //再执行关闭
                top.window.vtheme.common.closeCurIframe();
                //再调用回传函数
                if (typeof callback === 'function') {
                    callback.call(undefined, data);
                }
            }
        }
        $("body").on("switchModeCustom", function (e, mode) {
            createCookie("thememode", mode);
        });
        Form.events.faselect = function (form) {
            //绑定fachoose选择附件事件
            if ($(".faselect,.fachoose", form).length > 0) {
                $(".faselect,.fachoose", form).off('click').on('click', function () {
                    var that = this;
                    var multiple = $(this).data("multiple") ? $(this).data("multiple") : false;
                    var mimetype = $(this).data("mimetype") ? $(this).data("mimetype") : '';
                    var admin_id = $(this).data("admin-id") ? $(this).data("admin-id") : '';
                    var user_id = $(this).data("user-id") ? $(this).data("user-id") : '';
                    mimetype = mimetype.replace(/\/\*/ig, '/');
                    var url = $(this).data("url") ? $(this).data("url") : (typeof Backend !== 'undefined' ? "general/attachment/select" : "user/attachment");
                    Fast.api.open(url + "?element_id=" + $(this).attr("id") + "&multiple=" + multiple + "&mimetype=" + mimetype + "&admin_id=" + admin_id + "&user_id=" + user_id, __('Choose'), {
                        callback: function (data) {
                            var button = $("#" + $(that).attr("id"));
                            var maxcount = $(button).data("maxcount");
                            var input_id = $(button).data("input-id") ? $(button).data("input-id") : "";
                            maxcount = typeof maxcount !== "undefined" ? maxcount : 0;
                            if (input_id && data.multiple) {
                                var urlArr = [];
                                var inputObj = $("#" + input_id);
                                var value = $.trim(inputObj.val());
                                if (value !== "") {
                                    urlArr.push(inputObj.val());
                                }
                                var nums = value === '' ? 0 : value.split(/\,/).length;
                                var files = data.url !== "" ? data.url.split(/\,/) : [];
                                $.each(files, function (i, j) {
                                    var url = Config.upload.fullmode ? Fast.api.cdnurl(j) : j;
                                    urlArr.push(url);
                                });
                                if (maxcount > 0) {
                                    var remains = maxcount - nums;
                                    if (files.length > remains) {
                                        Toastr.error(__('You can choose up to %d file%s', remains));
                                        return false;
                                    }
                                }
                                var result = urlArr.join(",");
                                inputObj.val(result).trigger("change").trigger("validate");
                            } else if (input_id) {
                                var url = Config.upload.fullmode ? Fast.api.cdnurl(data.url) : data.url;
                                $("#" + input_id).val(url).trigger("change").trigger("validate");
                            }
                        }
                    });
                    return false;
                });
            }
        }

        Layer.alert = function (content, options, ok) {
            var type = typeof options === 'function';
            if (type) ok = options;
            delete options?.icon
            top.window.vtheme.common.alert(content, type ? {} : options, ok)
        };

        if (!(Config.controllername == 'addon' && Config.actionname == 'index') &&
            !(Config.controllername == 'addons' && Config.actionname == 'index')) {
            Layer.confirm = function (content, options, yes, cancel) {
                var type = typeof options === 'function';
                if (type) {
                    cancel = yes;
                    yes = options;
                }
                delete options?.icon
                top.window.vtheme.common.confirm(content, type ? {} : options, yes, cancel)
            };
        }

        Toastr.success = function (msg, title, options) {
            top.window.vtheme.common.Toastr('success', msg, { message: title, ...options })
        }
        Toastr.error = function (msg, title, options) {
            top.window.vtheme.common.Toastr('error', msg, { message: title, ...options })
        }
        Toastr.warning = function (msg, title, options) {
            top.window.vtheme.common.Toastr('warning', msg, { message: title, ...options })
        }
        Toastr.info = function (msg, title, options) {
            top.window.vtheme.common.Toastr('info', msg, { message: title, ...options })
        }

        if (!parent.Toastr) {
            parent.Toastr = {}
            parent.Toastr.success = function (msg, title, options) {
                top.window.vtheme.common.Toastr('success', msg, { message: title, ...options })
            }
            parent.Toastr.error = function (msg, title, options) {
                top.window.vtheme.common.Toastr('error', msg, { message: title, ...options })
            }
            parent.Toastr.warning = function (msg, title, options) {
                top.window.vtheme.common.Toastr('warning', msg, { message: title, ...options })
            }
            parent.Toastr.info = function (msg, title, options) {
                top.window.vtheme.common.Toastr('info', msg, { message: title, ...options })
            }
        }

        Form.events.validator = function (form, success, error, submit) {
            if (!form.is("form"))
                return;
            //绑定表单事件
            form.validator($.extend({
                rules: {
                    username: [/^\w{3,30}$/, __('Username must be 3 to 30 characters')],
                    password: [/^[\S]{6,30}$/, __('Password must be 6 to 30 characters')]
                },
                validClass: 'has-success',
                invalidClass: 'has-error',
                bindClassTo: '.form-group',
                formClass: 'n-default n-bootstrap',
                msgClass: 'n-right',
                stopOnError: true,
                display: function (elem) {
                    return $(elem).closest('.form-group').find(".control-label").text().replace(/\:/, '');
                },
                dataFilter: function (data) {
                    if (data.code === 1) {
                        return data.msg ? { "ok": data.msg } : '';
                    } else {
                        return data.msg;
                    }
                },
                target: function (input) {
                    var target = $(input).data("target");
                    if (target && $(target).length > 0) {
                        return $(target);
                    }
                    var $formitem = $(input).closest('.form-group'),
                        $msgbox = $formitem.find('span.msg-box');
                    if (!$msgbox.length) {
                        return [];
                    }
                    return $msgbox;
                },
                valid: function (ret) {
                    var that = this, submitBtn = $(".layer-footer [type=submit]", form);
                    that.holdSubmit(true);
                    submitBtn.addClass("disabled");
                    //验证通过提交表单
                    var submitResult = Form.api.submit($(ret), function (data, ret) {
                        that.holdSubmit(false);
                        submitBtn.removeClass("disabled");
                        if (false === $(this).triggerHandler("success.form", [data, ret])) {
                            return false;
                        }
                        if (typeof success === 'function') {
                            if (false === success.call($(this), data, ret)) {
                                return false;
                            }
                        }
                        //提示及关闭当前窗口
                        var msg = ret.hasOwnProperty("msg") && ret.msg !== "" ? ret.msg : __('Operation completed');
                        parent.Toastr.success(msg);
                        parent.document.querySelector(".btn-refresh").click()
                        top.window.vtheme.common.closeCurIframe();
                        return false;
                    }, function (data, ret) {
                        that.holdSubmit(false);
                        if (false === $(this).triggerHandler("error.form", [data, ret])) {
                            return false;
                        }
                        submitBtn.removeClass("disabled");
                        if (typeof error === 'function') {
                            if (false === error.call($(this), data, ret)) {
                                return false;
                            }
                        }
                    }, submit);
                    //如果提交失败则释放锁定
                    if (!submitResult) {
                        that.holdSubmit(false);
                        submitBtn.removeClass("disabled");
                    }
                    return false;
                }
            }, form.data("validator-options") || {}));

            //移除提交按钮的disabled类
            $(".layer-footer [type=submit],.fixed-footer [type=submit],.normal-footer [type=submit]", form).removeClass("disabled");
            //自定义关闭按钮事件
            form.on("click", ".layer-close", function () {
                if (window.name) {
                    var index = parent.Layer.getFrameIndex(window.name);
                    parent.Layer.close(index);
                }
                return false;
            });
        }
    }
});