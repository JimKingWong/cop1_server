<?php

namespace app\admin\controller\vtheme;

use app\common\controller\Backend;
use think\Config;
use think\Session;

class Index extends Backend
{
    protected $layout      = '';
    protected $noNeedRight = ['*'];

    public function index()
    {
        $menuConfig = $this->menuList([
            'dashboard' => 'hot',
            'addon'     => ['new', 'red'],
        ]);

        if ($this->request->isPost()) {
            $this->success('', null, $menuConfig);
        }

        $this->view->assign('title', __('Home'));
        $this->assignConfig('menuConfig', $menuConfig);
        $this->assignconfig('cookie', ['prefix' => config('cookie.prefix')]);
        $this->assignconfig('lang_switch_on', Config::get('lang_switch_on'));
        $this->assignconfig('admin', $this->auth->getUserInfo());

        return $this->view->fetch();
    }

    protected function menuList($badge = [])
    {
        $fixedPage  = $this->view->site['fixedpage'];
        $userRule   = $this->auth->getRuleList();
        $module     = request()->module();
        $refererUrl = Session::get('referer');
        $selected   = $referer   = [];

        $ruleList = collection(\app\admin\model\AuthRule::where('status', 'normal')
                ->where('ismenu', 1)
                ->order('weigh', 'desc')
                ->cache("__menu__")
                ->select())->toArray();

        $indexRuleList = \app\admin\model\AuthRule::where('status', 'normal')
            ->where('ismenu', 0)
            ->where('name', 'like', '%/index')
            ->column('name,pid');

        $pidArr = array_unique(array_filter(array_column($ruleList, 'pid')));

        foreach ($ruleList as $k => &$v) {
            if (!in_array($v['name'], $userRule)) {
                unset($ruleList[$k]);
                continue;
            }
            $indexRuleName = $v['name'] . '/index';
            if (isset($indexRuleList[$indexRuleName]) && !in_array($indexRuleName, $userRule)) {
                unset($ruleList[$k]);
                continue;
            }

            $v['key']      = $v['id'];
            $v['icon']     = $v['icon'] . ' fa-fw';
            $v['url']      = isset($v['url']) && $v['url'] ? $v['url'] : '/' . $module . '/' . $v['name'];
            $v['badge']    = $badge[$v['name']] ?? '';
            $v['title']    = __($v['title']);
            $v['label']    = $v['title'];
            $v['url']      = preg_match("/^((?:[a-z]+:)?\/\/|data:image\/)(.*)/i", $v['url']) ? $v['url'] : url($v['url']);
            $v['menutype'] = in_array($v['menutype'], ['dialog', 'ajax', 'blank']) ? $v['menutype'] : '';
            $selected      = $v['name'] == $fixedPage ? $v : $selected;
            $referer       = $v['url'] == $refererUrl ? $v : $referer;

            //unset($v['type'], $v['id']);
        }

        $lastArr    = array_unique(array_filter(array_column($ruleList, 'pid')));
        $pidDiffArr = array_diff($pidArr, $lastArr);
        //过滤掉父级菜单不存在的子菜单
        foreach ($ruleList as $index => $item) {
            if (in_array($item['key'], $pidDiffArr)) {
                unset($ruleList[$index]);
            }
        }

        if ($selected == $referer) {
            $referer = [];
        }

        $select_id = $referer ? $referer['id'] : ($selected ? $selected['id'] : 0);

        $TreeList = new \addons\vtheme\library\TreeList();
        $TreeList->instance()->init($ruleList);
        $menu        = $TreeList::instance()->getTreeArray(0);
        $multiplenav = Config::get('fastadmin.multiplenav');

        return [
            'menu'        => $menu,
            'selected'    => $selected,
            'referer'     => $referer,
            'select_id'   => $select_id,
            'multiplenav' => $multiplenav,
        ];
    }

    public function setting_theme()
    {
        if (!$this->request->isPost()) {
            $this->error();
        }

        $post = $this->request->post();

        $config = get_addon_config('vtheme');
        $data   = array_intersect_key($post, $config);
        $result = set_addon_config('vtheme', $data);

        if (!$result) {
            $this->error();
        }

        $this->success();
    }
}
