<?php

namespace addons\vtheme\library;

use fast\Tree;

class TreeList extends Tree
{
    public function getChild($myid)
    {
        $newarr = [];
        foreach ($this->arr as $value) {
            if (!isset($value['key'])) {
                continue;
            }
            if ($value[$this->pidname] == $myid) {
                $newarr[$value['key']] = $value;
            }
        }
        return $newarr;
    }

    public function getTreeArray($myid, $itemprefix = '')
    {
        $childs = $this->getChild($myid);
        $n = 0;
        $data = [];
        $number = 1;
        if ($childs) {
            $total = count($childs);
            foreach ($childs as $id => $value) {
                $j = $k = '';
                if ($number == $total) {
                    $j .= $this->icon[2];
                    $k = $itemprefix ? $this->nbsp : '';
                } else {
                    $j .= $this->icon[1];
                    $k = $itemprefix ? $this->icon[0] : '';
                }
                $spacer = $itemprefix ? $itemprefix . $j : '';
                $value['spacer'] = $spacer;
                $data[$n] = $value;
                $children = $this->getTreeArray($id, $itemprefix . $k . $this->nbsp);
                $data[$n]['children'] = count($children)?$children:null;
                $n++;
                $number++;
            }
        }
        return $data;
    }
}
