const { createApp, ref, provide, computed, watch } = Vue

createApp({
    components: {
        VTheme: vtheme.VTheme
    },
    setup() {
        const configInit = ref(config)
        const isDark = computed(() => {
            return vtheme.store.theme.isDark
        })
        provide('config', configInit)

        watch(isDark, (value) => {
            var iframes = document.getElementsByTagName("iframe");
            for (var i = 0; i < iframes.length; i++) {
                var iframe = iframes[i];
                try {
                    const $ = iframe.contentWindow.jQuery
                    if($){
                        iframe.contentWindow.Config.cookie = config.cookie
                        $("body").trigger("swithmode", [value? "dark" : "light"]);
                        $("body").trigger("switchModeCustom", value? "dark" : "light");
                    }else{
                        if(iframe.contentWindow.vthemeClient){
                            iframe.contentWindow.vthemeClient.store.switchDark()
                            iframe.contentWindow.document.body.classList.toggle('darktheme');
                        }
                    }
                } catch (e) {
                    console.log(e);
                }
            }
        })

        return {
        }
    }
}).mount('#app')