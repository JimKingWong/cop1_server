<?php
namespace addons\vtheme;

use think\Addons;
use think\Loader;
use think\Request;
use traits\controller\Jump;

Loader::import('controller/Jump', TRAIT_PATH, EXT);

/**
 * 插件
 */
class Vtheme extends Addons
{
    use Jump;
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        return true;
    }

    public function moduleInit(Request $request)
    {
        if ($request->module() === 'admin'
            && $request->controller() === 'Index'
            && $request->action() === 'index') {
            $this->redirect('vtheme/index', [], 302);
        }
    }

    public function configInit(&$params)
    {
        $config = $this->getConfig();

        $params['vtheme'] = $this->removeEmptyValues($config);
    }

    protected function removeEmptyValues($array)
    {
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $array[$key] = $this->removeEmptyValues($value);
                if (empty($array[$key])) {
                    unset($array[$key]);
                }
            } elseif (empty($value)) {
                unset($array[$key]);
            }
        }
        return $array;
    }
}
